﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_3
{
    interface ITurnable
    {
        void turn();
    }


    class Program : ITurnable
    {


        static void Main(string[] args)
        {
           
            page aPage = new page();
            corner con= new corner();
            pancake aCake = new pancake();
            leaf aLeaf = new leaf();
            aPage.turn();
            con.turn();
            aCake.turn();
            aLeaf.turn();
            
           

            Console.ReadLine();
        }

  

        public class page
        {

            public void turn()
            {
                Console.WriteLine("You turn a page in a book");
            }
        }
       public class corner
        {

            public void turn()
            {
                Console.WriteLine("A car turned on a sharp corner at high speed.");
            }
        }

        public class pancake
        {
            public void turn()
            {
                Console.WriteLine("Pancake is delicious");
            }
        }
          
        
        public class leaf
            {
                public void turn()
                {
                    Console.WriteLine("Wind drops a leaf from a tree");
                }
            }



        public void turn()
        {
            Console.WriteLine("Typical messages on output:");
        }
    }
}
