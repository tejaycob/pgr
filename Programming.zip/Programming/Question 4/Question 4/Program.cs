﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_4
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] Array = { 0.99, 1.99, 2.99, 3.99, 4.99, 5.99, 6.99, 7.99, 8.99, 9.99, 10.99, 11.99, 12.99, 13.99, 14.99, 15.99, 16.99, 17.99, 18.99, 19.99 };
            int check;
            string name;

            Console.WriteLine("Hi there! Before we begin, what's your name?");
            name = Console.ReadLine();

            for (int i = 0; i < Array.Length; i++)
            {
                try
                {
                    Console.WriteLine("Hi {0}! Enter a subscript value of the array (0 - 19): ", name);
                   check = int.Parse(Console.ReadLine());
                    Console.WriteLine("Congrats! The number in position {0} is: {1}.", check, Array[check]);
                }
                catch (IndexOutOfRangeException)
                {

                    Console.WriteLine("Oops! That subscript value is out of range, {0}. Time to exit the program. Buh bye!", name);


                    Console.ReadLine();
                }
            }
        }
    }
}
