﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_2
{
    class Program
    {
        private string Name;
        private double SalesAmount;
        private readonly double Commission = 200;

  
    public Program(string name, double salesamount, double rate)
    {
        Name = name;
        SalesAmount = salesamount;
        Commission = rate;
        Commission = salesamount * rate;
    }
   
    
     public Program(string name, double salesamount)
    {
      
     
    }
 public static void Called ()
    {
        
    
        Console.WriteLine("Enter name of Salesperson :");
     string  Nam = Console.ReadLine();
     

        Console.WriteLine("Enter Sales Amount :");
    double Sale = Convert.ToDouble(Console.ReadLine());

    //  Three arguments
    Console.WriteLine(" ");
    Console.WriteLine("Three argument constructor:");

    Console.WriteLine("The name of Sales Person: " + Nam);
    Console.WriteLine("Amount of sale: " + Sale );

    Console.WriteLine("Commission= " + (Sale * 200.00));

     // Two arguments

    Console.WriteLine(" ");
    Console.WriteLine("Two Arguments constructor:");

    Console.WriteLine("The name of Sales Person: " + Nam);
    Console.WriteLine("Amount of sale: " + "R" + Sale);

    Console.WriteLine("Commission= " + "R" + 0.00);

    // one arguments

    Console.WriteLine(" ");
    Console.WriteLine("One Arguments constructor:");

    Console.WriteLine("The name of Sales Person: " + Nam);
    Console.WriteLine("Amount of sale: " + "R" + 0.00);

    Console.WriteLine("Commission= " + "R" + 0.00);
    }
 public Program(string name)
    {
        Name = name;
        SalesAmount = 0;
        Commission = 0;
    }
     public static double operator +(Program s1, Program s2)
     {
         return s1.SalesAmount + s2.Commission;
     }
        static void Main(string[] args)
        {
            Called();
            Program sale1 = new Program("");
            Program sale2 = new Program("");
            
            Console.ReadLine();
        } 
    }

      }










    

