﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_1
{
    class Program
    {
        static void Main(string[] args)
        {

            int userInput;
            int n, count = 1;
            float x, average, sum = 0;


            Console.WriteLine("Enter integer number?");
            n = Convert.ToInt32(Console.ReadLine());
            while (count <= n)
            {
                
                userInput = Convert.ToInt32(Console.ReadLine());
                sum += userInput;
                ++count;
            }
            average = (float)sum / (n);
            Console.WriteLine("The Average is" + average);

            Console.ReadLine();
        }
    }
}